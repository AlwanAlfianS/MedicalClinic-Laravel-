<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="{{ asset('resources') }}/assets/img/icon.png" />
	<link rel="icon" type="image/png" href="{{ asset('resources') }}/assets/img/icon.png" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>MedicalClinic | Dashboard</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="{{ asset('resources') }}/assets/css/bootstrap.min.css" rel="stylesheet" />

    <!--  Material Dashboard CSS    -->
    <link href="{{ asset('resources') }}/assets/css/material-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="{{ asset('resources') }}/assets/css/demo.css" rel="stylesheet" />

    <link href="{{ asset('resources') }}/assets/js/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet" />
    <link href="{{ asset('resources') }}/assets/js/datatables-responsive/dataTables.responsive.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons' rel='stylesheet' type='text/css'>

    @stack('style')

</head>

<body>

	<div class="wrapper">
	    <div class="sidebar" data-color="red" data-image="{{ asset('resources') }}/assets/img/sidebar-1.jpg">

			<div class="logo">
				<a href="{{ url('/') }}">
                   <div class="logo-container">
                        <div class="logo-dashboard text-center">
                            <img src="{{ asset('resources') }}/assets/img/logo.png" alt="Creative Tim Logo">
                        </div>
                    </div>
                </a>
			</div>


	    	<div class="sidebar-wrapper">
				
				<ul class="nav">
				@if ($active == 'user')
	                <li class="active">
				@else
					<li>
				@endif
	                    <a href="{{ url('/user') }}">
	                        <p>Data User</p>
	                    </a>
	                </li>
	            @if ($active == 'pasien')
	                <li class="active">
				@else
					<li>
				@endif
	                    <a href="{{ url('/pasien') }}">
	                        <p>Pasien</p>
	                    </a>
	                </li>
	            @if ($active == 'dokter')
	                <li class="active">
				@else
					<li>
				@endif
	                    <a href="{{ url('/dokter') }}">
	                        <p>Dokter</p>
	                    </a>
	                </li>
	            @if ($active == 'poliklinik')
	                <li class="active">
				@else
					<li>
				@endif
	                    <a href="{{ url('/poliklinik') }}">
	                        <p>Poliklinik</p>
	                    </a>
	                </li>
	            @if ($active == 'obat')
	                <li class="active">
				@else
					<li>
				@endif
	                    <a href="{{ url('/obat') }}">
	                        <p>Obat</p>
	                    </a>
	                </li>
				@if ($active == 'resep')
	                <li class="active">
				@else
					<li>
				@endif
	                    <a href="{{ url('/resep') }}">
	                        <p>Resep</p>
	                    </a>
	                </li>
				@if ($active == 'pembayaran')
	                <li class="active">
				@else
					<li>
				@endif
	                    <a href="{{ url('/pembayaran') }}">
	                        <p>Pembayaran</p>
	                    </a>
	                </li>
	            </ul>
	    	</div>
		</div>

		<div class="main-panel">
			<nav class="navbar navbar-transparent navbar-absolute">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#">Dashboard Medical Clinic Center</a>
					</div>
					<div class="collapse navbar-collapse">
						<ul class="nav navbar-nav navbar-right">
							<li>
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">
									<i class="material-icons">dashboard</i>
									<p class="hidden-lg hidden-md">Dashboard</p>
								</a>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">
									<i class="material-icons">person</i> {{ session('username') }}
									<p class="hidden-lg hidden-md">profile</p>
								</a>
								<ul class="dropdown-menu">
									<li>
										<form action="{{ url('logout') }}" method="get">
											{{ csrf_field() }}
											<a href="#"><button type="submit">Logout</button></a>
										</form>
									</li>
								</ul>
							</li>
						</ul>

						<form class="navbar-form navbar-right" role="search">
							<div class="form-group  is-empty">
	                        	<input type="text" class="form-control" placeholder="Search">
	                        	<span class="material-input"></span>
							</div>
							<button type="submit" class="btn btn-white btn-round btn-just-icon">
								<i class="material-icons">search</i><div class="ripple-container"></div>
							</button>
	                    </form>
					</div>
				</div>
			</nav>

			@yield('content')

			@include('templates/footer')