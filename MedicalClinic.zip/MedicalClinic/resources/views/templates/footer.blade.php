			<footer class="footer">
	            <div class="container-fluid">
	                <nav class="pull-left">
	                    <ul>
	                        <li>
	                            <a href="{{ url('/') }}">
	                                Home
	                            </a>
	                        </li>
	                        <li>
	                            <a href="#">
	                                Company
	                            </a>
	                        </li>
	                        <li>
	                            <a href="#">
	                                Portfolio
	                            </a>
	                        </li>
	                        <li>
	                            <a href="#">
	                               Blog
	                            </a>
	                        </li>
	                    </ul>
	                </nav>
	                <p class="copyright pull-right">
	                    &copy; <script>document.write(new Date().getFullYear())</script> <a href="#" class="txt-red">Alwan Ryan Syamsul</a>, made with love for a better web
	                </p>
	            </div>
	        </footer>
	    </div>
	</div>

</body>

	<!--   Core JS Files   -->
	<script src="{{ asset('resources') }}/assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
	<script src="{{ asset('resources') }}/assets/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="{{ asset('resources') }}/assets/js/material.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="{{ asset('resources') }}/assets/js/chartist.min.js"></script>

	<!--  Notifications Plugin    -->
	<script src="{{ asset('resources') }}/assets/js/bootstrap-notify.js"></script>

	<!--  Google Maps Plugin    -->
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

	<!-- Material Dashboard javascript methods -->
	<script src="{{ asset('resources') }}/assets/js/material-dashboard.js"></script>

	<!-- Material Dashboard DEMO methods, don't include it in your project! -->
	<script src="{{ asset('resources') }}/assets/js/demo.js"></script>

	<script src="{{ asset('resources') }}/assets/js/datatables/js/jquery.dataTables.min.js"></script>
	<script src="{{ asset('resources') }}/assets/js/datatables-plugins/dataTables.bootstrap.min.js"></script>
	<script src="{{ asset('resources') }}/assets/js/datatables-responsive/dataTables.responsive.js"></script>

	<script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>

</html>
