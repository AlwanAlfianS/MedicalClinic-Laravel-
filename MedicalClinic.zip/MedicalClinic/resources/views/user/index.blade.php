			@extends('templates/header')

			@section('content')
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
	                        <a href="{{ url('user/add') }}"><button class="btn btn-default"><i class="material-icons">add</i> Add Data User</button></a>
	                        <div class="card card-plain">
	                            <div class="card-header" data-background-color="red">
	                            		<h4 class="title">Data User</h4>
	                                <p class="category">Data User MedicalClinic</p>
	                            </div>
	                            <div class="card-content table-responsive">
	                                <table class="table" id="dataTables-example">
	                                    <thead>
	                                    	<th><b>No</b></th>
	                                    	<th><b>Foto</b></th>
	                                    	<th><b>Username</b></th>
											@foreach ($result as $row)
											@if($row->level == 1)
												<th><b>Action</b></th>
											@endif
											@endforeach
	                                    </thead>
	                                    <tbody>
	                                    @foreach ($result as $row)
	                                        <tr>
	                                        	<td>{{ $i++ }}</td>
	                                        	<td><img src="{{ url('resources/assets/upload/'.$row->foto) }}" width="100px"/></td>
	                                        	<td>{{ $row->username }}</td>
												@if($row->level == 1)
												<td>
													<a href="{{ url('user/edit/'.$row->id_user) }}"><button class="btn btn-success btn-just-icon"><i class="material-icons"></i> Edit</button></a>
													<a href="{{ url('user/delete/'.$row->id_user) }}"><button class="btn btn-danger btn-just-icon"><i class="material-icons"></i> Clear</button></a>
												</td>
												@endif
	                                        </tr>
	                                    @endforeach
	                                    </tbody>
	                                </table>

	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        @endsection