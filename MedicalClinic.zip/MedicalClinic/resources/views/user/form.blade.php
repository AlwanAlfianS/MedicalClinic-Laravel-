			@extends('templates/header')

			@section('content')
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
						@if (session('success')) 
							<div class="alert alert-success">
								<button type="button" aria-hidden="true" class="close">×</button>
								<span><b> {{ session('success') }} </b></span>
							</div>
						@endif
						@if (session('error'))
							<div class="alert alert-danger">
								<button type="button" aria-hidden="true" class="close">×</button>
								<span><b>{{ session('error') }} </b></span>
							</div>
						@endif
	                    <a href="{{ url('user') }}"><button class="btn btn-default"><i class="material-icons">keyboard_arrow_left</i> Back</button></a>
	                        <div class="card">
	                            <div class="card-header" data-background-color="red">
	                                <h4 class="title">Form Data User</h4>
	                                <p class="category">Complete Data User </p>
	                            </div>
	                            <div class="card-content">
	                                <form action="{{ empty($edit) ? url('user/add') : url('user/edit/'. @$result->id_user) }}" method="post" enctype="multipart/form-data">
										{{ csrf_field() }}
										@if(!empty($result))
											{{ method_field('PATCH') }}
										@endif
	                                    <div class="row">
	                                        <div class="col-md-12">
												<div class="form-group label-floating has-error">
													<label class="control-label">Username</label>
													<input name="username" type="text" class="form-control" value="{{ @$result->username }}">
												</div>
	                 
												<div class="form-group label-floating has-error">
													<label class="control-label">Password</label>
													<input name="password" type="password" class="form-control">
												</div>

												<div class="form-group is-empty is-fileinput has-error">
										            <input type="file" id="inputFile4" multiple="" name="foto" ">
										            <div class="input-group">
										              <input type="text" readonly="" class="form-control" placeholder="Choose image..." value="{{ @$result->foto }}">
										                <span class="input-group-btn input-group-sm">
										                  <button type="button" class="btn btn-fab btn-fab-mini">
										                    <i class="material-icons">add_a_photo</i>
										                  </button>
										                </span>
										            </div>
												 </div>
	                                        </div>
	                                    </div>

	                                    <button type="submit" class="btn btn-danger pull-right">Submit</button>
	                                    <div class="clearfix"></div>
	                                </form>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        @endsection