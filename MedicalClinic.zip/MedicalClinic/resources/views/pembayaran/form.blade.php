			@extends('templates/header')

			@section('content')
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
	                    <a href="{{ url('/pembayaran') }}"><button class="btn btn-default"><i class="material-icons">keyboard_arrow_left</i> Back</button></a>
	                        <div class="card">
	                            <div class="card-header" data-background-color="red">
	                                <h4 class="title">Form Data Pembayaran</h4>
	                                <p class="category">Complete data pembayaran</p>
	                            </div>
	                            <div class="card-content">
	                                <form action="{{ url('/pembayaran/add') }}" method="post">
	                                    <div class="row">
	                                        <div class="col-md-12">
												<div class="form-group has-error">
													<label class="label txt-red">Pasien</label>
													<select class="form-control">
													  <option>1</option>
													  <option>2</option>
													  <option>3</option>
													  <option>4</option>
													  <option>5</option>
													</select>
												</div>
	                 
												<div class="form-group label-floating has-error">
													<label class="control-label">Total Pembayaran</label>
													<input type="number" class="form-control" >
												</div>
	                                        </div>
	                                    </div>

	                                    <button type="submit" class="btn btn-danger pull-right">Submit</button>
	                                    <div class="clearfix"></div>
	                                </form>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        @endsection