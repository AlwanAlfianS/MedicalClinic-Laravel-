			@extends('templates/header')

			@section('content')
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
						@if (session('success')) 
							<div class="alert alert-success">
								<button type="button" aria-hidden="true" class="close">×</button>
								<span><b> {{ session('success') }} </b></span>
							</div>
						@endif
						@if (session('error'))
							<div class="alert alert-danger">
								<button type="button" aria-hidden="true" class="close">×</button>
								<span><b>{{ session('error') }} </b></span>
							</div>
						@endif
	                    <a href="{{ url('obat') }}"><button class="btn btn-default"><i class="material-icons">keyboard_arrow_left</i> Back</button></a>
	                        <div class="card">
	                            <div class="card-header" data-background-color="red">
	                                <h4 class="title">Form Data Obat</h4>
	                                <p class="category">Complete Data Obat</p>
	                            </div>
	                            <div class="card-content">
	                                <form action="{{ empty($edit) ? url('obat/add') : url('obat/edit/'. @$result->kd_obat) }}" method="post">
										{{ csrf_field() }}
										@if(!empty($result))
											{{ method_field('PATCH') }}
										@endif
	                                    <div class="row">
	                                        <div class="col-md-12">
												<div class="form-group label-floating has-error">
													<label class="control-label">Nama</label>
													<input name="nama_obat" type="text" class="form-control" value="{{ @$result->nama_obat }}">
												</div>
	                 
												<div class="form-group has-error">
													<label class="label txt-red">Jenis Obat</label>
													<select name="jenis_obat" class="form-control">
													  <option value="Serbuk" {{ @$result->jenis_obat == 'Serbuk' ? 'selected' : '' }}>Serbuk</option>
													  <option value="Sirup" {{ @$result->jenis_obat == 'Sirup' ? 'selected' : '' }}>Sirup</option>
													  <option value="Tablet" {{ @$result->jenis_obat == 'Tablet' ? 'selected' : '' }}>Tablet</option>
													  <option value="Kapsul" {{ @$result->jenis_obat == 'Kapsul' ? 'selected' : '' }}>Kapsul</option>
													</select>
												</div>

												<div class="form-group has-error">
													<label class="label txt-red">Kategori</label>
													<select name="kategori" class="form-control">
													  <option value="Obat Bebas" {{ @$result->kategori == 'Obat Bebas' ? 'selected' : '' }}>Obat Bebas</option>
													  <option value="Obat Bebas Terbatas" {{ @$result->kategori == 'Obat Bebas Terbatas' ? 'selected' : '' }}>Obat Bebas Terbatas</option>
													  <option value="Obat Keras" {{ @$result->kategori == 'Obat Keras' ? 'selected' : '' }}>Obat Keras</option>
													</select>
												</div>

												<div class="form-group label-floating has-error">
													<label class="control-label">Harga Obat</label>
													<input name="harga_obat" type="number" class="form-control" value="{{ @$result->harga_obat }}">
												</div>

												<div class="form-group label-floating has-error">
													<label class="control-label">Jumlah Obat</label>
													<input name="jml_obat" type="number" class="form-control" value="{{ @$result->jml_obat }}">
												</div>
	                                        </div>
	                                    </div>

	                                    <button type="submit" class="btn btn-danger pull-right">
											@if (empty($edit))
												Submit
											@else
												Edit
											@endif
										</button>
	                                    <div class="clearfix"></div>
	                                </form>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        @endsection