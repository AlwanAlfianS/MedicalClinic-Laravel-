			@extends('templates/header')

			@section('content')
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
							@if (session('success')) 
								<div class="alert alert-success">
									<button type="button" aria-hidden="true" class="close">×</button>
									<span><b> {{ session('success') }} </b></span>
								</div>
							@endif
							@if (session('error'))
								<div class="alert alert-danger">
									<button type="button" aria-hidden="true" class="close">×</button>
									<span><b>{{ session('error') }} </b></span>
								</div>
							@endif
	                        <a href="{{ url('obat/add') }}"><button class="btn btn-default"><i class="material-icons">add</i> Add Data Obat</button></a>
	                        <div class="card card-plain">
	                            <div class="card-header" data-background-color="red">
	                            		<h4 class="title">Data Obat</h4>
	                                <p class="category">Data Obat MedicalClinic</p>
	                            </div>
	                            <div class="card-content table-responsive">
	                                <table class="table" id="dataTables-example">
	                                    <thead>
	                                    	<th><b>No</b></th>
	                                    	<th><b>Nama Obat</b></th>
	                                    	<th><b>Jenis Obat</b></th>
	                                    	<th><b>Kategori</b></th>
	                                    	<th><b>Harga Obat</b></th>
	                                    	<th><b>Stok Obat</b></th>
											<th><b>Action</b></th>
	                                    </thead>
	                                    <tbody>
	                                    @foreach ($result as $row)
	                                        <tr>
	                                        	<td>{{ $i++ }}</td>
	                                        	<td>{{ $row->nama_obat }}</td>
												<td>{{ $row->jenis_obat }}</td>
												<td>{{ $row->kategori }}</td>
												<td>Rp.{{ $row->harga_obat }}</td>
												<td>{{ $row->jml_obat }}</td>
												<td>
													<a href="{{ url('obat/edit/'.$row->kd_obat) }}"><button class="btn btn-success btn-just-icon"><i class="material-icons"></i> Edit</button></a>
													<a href="{{ url('obat/delete/'.$row->kd_obat) }}"><button class="btn btn-danger btn-just-icon"><i class="material-icons"></i> Clear</button></a>
												</td>
	                                        </tr>
	                                    @endforeach
	                                    </tbody>
	                                </table>

	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        @endsection