			@extends('templates/header')

			@section('content')
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
	                        <a href="{{ url('dokter/add') }}"><button class="btn btn-default"><i class="material-icons">add</i> Add Data Dokter</button></a>
	                        <div class="card card-plain">
	                            <div class="card-header" data-background-color="red">
	                            		<h4 class="title">Data Dokter</h4>
	                                <p class="category">Data dokter MedicalClinic</p>
	                            </div>
	                            <div class="card-content table-responsive">
	                                <table class="table" id="dataTables-example">
	                                    <thead>
	                                    	<th><b>No</b></th>
	                                    	<th><b>Nama</b></th>
	                                    	<th><b>Spesialis</b></th>
											<th><b>Telepon</b></th>
											<th><b>Poliklinik</b></th>
											<th><b>Action</b></th>
	                                    </thead>
	                                    <tbody>
	                                    @foreach ($result as $row)
	                                        <tr>
	                                        	<td>{{ $i++ }}</td>
	                                        	<td>{{ $row->nama_dokter }}</td>
												<td>{{ $row->spesialis }}</td>
												<td>{{ $row->tlp_dokter }}</td>
												<td>{{ $row->kd_poliklinik }}</td>
												<td>
													<button class="btn btn-success btn-just-icon"><i class="material-icons"></i></button>
													<button class="btn btn-danger btn-just-icon"><i class="material-icons"></i></button>
												</td>
	                                        </tr>
	                                    @endforeach
	                                    </tbody>
	                                </table>

	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        @endsection