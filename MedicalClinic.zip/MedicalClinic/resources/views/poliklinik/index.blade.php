			@extends('templates/header')

			@section('content')
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
							@if (session('success')) 
								<div class="alert alert-success">
									<button type="button" aria-hidden="true" class="close">×</button>
									<span><b> {{ session('success') }} </b></span>
								</div>
							@endif
							@if (session('error'))
								<div class="alert alert-danger">
									<button type="button" aria-hidden="true" class="close">×</button>
									<span><b>{{ session('error') }} </b></span>
								</div>
							@endif
							<a href="{{ url('poliklinik/add') }}"><button class="btn btn-default"><i class="material-icons">add</i> Add Data Poliklinik</button></a>
	                        <div class="card card-plain">
	                            <div class="card-header" data-background-color="red">
	                            		<h4 class="title">Data Poliklinik</h4>
	                                <p class="category">Data Poliklinik MedicalClinic</p>
	                            </div>
	                            <div class="card-content table-responsive">
	                                <table class="table" id="dataTables-example">
	                                    <thead>
	                                    	<th><b>No</b></th>
	                                    	<th><b>Nama Poliklinik</b></th>
	                                    	<th><b>Tarif</b></th>
											<th><b>Action</b></th>
	                                    </thead>
	                                    <tbody>
	                                    @foreach ($result as $row)
	                                        <tr>
	                                        	<td>{{ $i++ }}</td>
	                                        	<td>{{ $row->nama_poliklinik }}</td>
												<td>Rp.{{ $row->tarif }}</td>
												<td>
													<a href="{{ url('poliklinik/edit/'.$row->kd_poliklinik) }}"><button class="btn btn-success btn-just-icon"><i class="material-icons"></i> Edit</button></a>
													<a href="{{ url('/poliklinik/delete/'.$row->kd_poliklinik) }}"><button class="btn btn-danger btn-just-icon"><i class="material-icons"></i> Clear</button></a>
												</td>
	                                        </tr>
	                                    @endforeach
	                                    </tbody>
	                                </table>

	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        @endsection