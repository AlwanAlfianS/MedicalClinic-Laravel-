			@extends('templates/header')

			@section('content')
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
	                        <a href="{{ url('pasien/add') }}"><button class="btn btn-default"><i class="material-icons">add</i> Add Data Pasien</button></a>
	                        <div class="card card-plain">
	                            <div class="card-header" data-background-color="red">
	                            		<h4 class="title">Data Pasien</h4>
	                                <p class="category">Data pasien MedicalClinic</p>
	                            </div>
	                            <div class="card-content table-responsive">
	                                <table class="table" id="dataTables-example">
	                                    <thead>
	                                    	<th><b>No</b></th>
	                                    	<th><b>Foto</b></th>
	                                    	<th><b>Nama</b></th>
											<th><b>Alamat</b></th>
											<th><b>Jenis Kelamin</b></th>
											<th><b>Usia</b></th>
											<th><b>Telepon</b></th>
											<th><b>Action</b></th>
	                                    </thead>
	                                    <tbody>
	                                    @foreach ($result as $row)
	                                        <tr>
	                                        	<td>{{ $i++ }}</td>
	                                        	<td>photo</td>
	                                        	<td>{{ $row->nama_pasien }}</td>
												<td>{{ $row->alamat_pasien }}</td>
												<td>{{ $row->jk_pasien }}</td>
												<td>{{ $row->umur_pasien }} tahun</td>
												<td>{{ $row->tlp_pasien }}</td>
												<td>
													<button class="btn btn-success btn-just-icon"><i class="material-icons">Edit</i></button>
													<button class="btn btn-danger btn-just-icon"><i class="material-icons">Clear</i></button>
												</td>
	                                        </tr>
	                                    @endforeach
	                                    </tbody>
	                                </table>

	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        @endsection