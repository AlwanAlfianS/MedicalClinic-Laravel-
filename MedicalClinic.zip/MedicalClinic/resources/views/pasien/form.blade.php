			@extends('templates/header')

			@section('content')
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
	                    <a href="{{ url('/pasien') }}"><button class="btn btn-default"><i class="material-icons">keyboard_arrow_left</i> Back</button></a>
	                        <div class="card">
	                            <div class="card-header" data-background-color="red">
	                                <h4 class="title">Form Data Pasien</h4>
	                                <p class="category">Complete data Pasien</p>
	                            </div>
	                            <div class="card-content">
	                                <form action="{{ url('/pasien/add') }}" method="post">
	                                    <div class="row">
	                                        <div class="col-md-12">
												<div class="form-group label-floating has-error">
													<label class="control-label">Nama</label>
													<input type="text" class="form-control" >
												</div>
	                 
												<div class="form-group label-floating has-error">
													<label class="control-label">Alamat</label>
													<textarea class="form-control" rows="5"></textarea>
												</div>

												<div class="form-group">
													<label class="label txt-red">Jenis Kelamin</label>
													<div class="radio">
														<label>
															<input type="radio" name="optionsRadios">
															Laki - laki
														</label>
													</div>
													<div class="radio">
														<label>
															<input type="radio" name="optionsRadios" checked="true">
															Perempuan
														</label>
													</div>
												</div>

												<div class="form-group label-floating has-error">
													<label class="control-label">Usia</label>
													<input type="number" class="form-control" >
												</div>

												<div class="form-group label-floating has-error">
													<label class="control-label">Telepon</label>
													<input type="number" class="form-control" >
												</div>

												<div class="form-group label-floating has-error">
													<label class="control-label">Keterangan Penyakit</label>
													<input type="text" class="form-control" >
												</div>

												<div class="form-group">
													<label class="label txt-red">Poliklinik</label>
													<select class="form-control">
													  <option>1</option>
													  <option>2</option>
													  <option>3</option>
													  <option>4</option>
													  <option>5</option>
													</select>
												</div>

												<div class="form-group">
													<label class="label txt-red">Dokter</label>
													<select class="form-control">
													  <option>1</option>
													  <option>2</option>
													  <option>3</option>
													  <option>4</option>
													  <option>5</option>
													</select>
												</div>

												<div class="form-group is-empty is-fileinput">
										            <input type="file" id="inputFile4" multiple="">
										            <div class="input-group">
										              <input type="text" readonly="" class="form-control" placeholder="Choose image...">
										                <span class="input-group-btn input-group-sm">
										                  <button type="button" class="btn btn-fab btn-fab-mini">
										                    <i class="material-icons">add_a_photo</i>
										                  </button>
										                </span>
										            </div>
												 </div>
	                                        </div>
	                                    </div>

	                                    <button type="submit" class="btn btn-danger pull-right">Submit</button>
	                                    <div class="clearfix"></div>
	                                </form>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        @endsection