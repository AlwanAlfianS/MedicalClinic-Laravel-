			

			<?php $__env->startSection('content'); ?>
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
	                        <a href="<?php echo e(url('user/add')); ?>"><button class="btn btn-default"><i class="material-icons">add</i> Add Data User</button></a>
	                        <div class="card card-plain">
	                            <div class="card-header" data-background-color="red">
	                            		<h4 class="title">Data User</h4>
	                                <p class="category">Data User MedicalClinic</p>
	                            </div>
	                            <div class="card-content table-responsive">
	                                <table class="table" id="dataTables-example">
	                                    <thead>
	                                    	<th><b>No</b></th>
	                                    	<th><b>Foto</b></th>
	                                    	<th><b>Username</b></th>
											<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
											<?php if($row->level == 1): ?>
												<th><b>Action</b></th>
											<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                                    </thead>
	                                    <tbody>
	                                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                                        <tr>
	                                        	<td><?php echo e($i++); ?></td>
	                                        	<td><img src="<?php echo e(url('resources/assets/upload/'.$row->foto)); ?>" width="100px"/></td>
	                                        	<td><?php echo e($row->username); ?></td>
												<?php if($row->level == 1): ?>
												<td>
													<a href="<?php echo e(url('user/edit/'.$row->id_user)); ?>"><button class="btn btn-success btn-just-icon"><i class="material-icons"></i> Edit</button></a>
													<a href="<?php echo e(url('user/delete/'.$row->id_user)); ?>"><button class="btn btn-danger btn-just-icon"><i class="material-icons"></i> Clear</button></a>
												</td>
												<?php endif; ?>
	                                        </tr>
	                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                                    </tbody>
	                                </table>

	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        <?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>