<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('resources')); ?>/assets/img/icon.png" />
	<link rel="icon" type="image/png" href="<?php echo e(asset('resources')); ?>/assets/img/icon.png" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>MedicalClinic | Dashboard</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="<?php echo e(asset('resources')); ?>/assets/css/bootstrap.min.css" rel="stylesheet" />

    <!--  Material Dashboard CSS    -->
    <link href="<?php echo e(asset('resources')); ?>/assets/css/material-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo e(asset('resources')); ?>/assets/css/demo.css" rel="stylesheet" />

    <link href="<?php echo e(asset('resources')); ?>/assets/js/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet" />
    <link href="<?php echo e(asset('resources')); ?>/assets/js/datatables-responsive/dataTables.responsive.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons' rel='stylesheet' type='text/css'>

    <?php echo $__env->yieldPushContent('style'); ?>

</head>

<body>

	<div class="wrapper">
	    <div class="sidebar" data-color="red" data-image="<?php echo e(asset('resources')); ?>/assets/img/sidebar-1.jpg">

			<div class="logo">
				<a href="<?php echo e(url('/')); ?>">
                   <div class="logo-container">
                        <div class="logo-dashboard text-center">
                            <img src="<?php echo e(asset('resources')); ?>/assets/img/logo.png" alt="Creative Tim Logo">
                        </div>
                    </div>
                </a>
			</div>


	    	<div class="sidebar-wrapper">
				
				<ul class="nav">
				<?php if($active == 'user'): ?>
	                <li class="active">
				<?php else: ?>
					<li>
				<?php endif; ?>
	                    <a href="<?php echo e(url('/user')); ?>">
	                        <p>Data User</p>
	                    </a>
	                </li>
	            <?php if($active == 'pasien'): ?>
	                <li class="active">
				<?php else: ?>
					<li>
				<?php endif; ?>
	                    <a href="<?php echo e(url('/pasien')); ?>">
	                        <p>Pasien</p>
	                    </a>
	                </li>
	            <?php if($active == 'dokter'): ?>
	                <li class="active">
				<?php else: ?>
					<li>
				<?php endif; ?>
	                    <a href="<?php echo e(url('/dokter')); ?>">
	                        <p>Dokter</p>
	                    </a>
	                </li>
	            <?php if($active == 'poliklinik'): ?>
	                <li class="active">
				<?php else: ?>
					<li>
				<?php endif; ?>
	                    <a href="<?php echo e(url('/poliklinik')); ?>">
	                        <p>Poliklinik</p>
	                    </a>
	                </li>
	            <?php if($active == 'obat'): ?>
	                <li class="active">
				<?php else: ?>
					<li>
				<?php endif; ?>
	                    <a href="<?php echo e(url('/obat')); ?>">
	                        <p>Obat</p>
	                    </a>
	                </li>
				<?php if($active == 'resep'): ?>
	                <li class="active">
				<?php else: ?>
					<li>
				<?php endif; ?>
	                    <a href="<?php echo e(url('/resep')); ?>">
	                        <p>Resep</p>
	                    </a>
	                </li>
				<?php if($active == 'pembayaran'): ?>
	                <li class="active">
				<?php else: ?>
					<li>
				<?php endif; ?>
	                    <a href="<?php echo e(url('/pembayaran')); ?>">
	                        <p>Pembayaran</p>
	                    </a>
	                </li>
	            </ul>
	    	</div>
		</div>

		<div class="main-panel">
			<nav class="navbar navbar-transparent navbar-absolute">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="#">Dashboard Medical Clinic Center</a>
					</div>
					<div class="collapse navbar-collapse">
						<ul class="nav navbar-nav navbar-right">
							<li>
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">
									<i class="material-icons">dashboard</i>
									<p class="hidden-lg hidden-md">Dashboard</p>
								</a>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">
									<i class="material-icons">person</i> <?php echo e(session('username')); ?>

									<p class="hidden-lg hidden-md">profile</p>
								</a>
								<ul class="dropdown-menu">
									<li>
										<form action="<?php echo e(url('logout')); ?>" method="get">
											<?php echo e(csrf_field()); ?>

											<a href="#"><button type="submit">Logout</button></a>
										</form>
									</li>
								</ul>
							</li>
						</ul>

						<form class="navbar-form navbar-right" role="search">
							<div class="form-group  is-empty">
	                        	<input type="text" class="form-control" placeholder="Search">
	                        	<span class="material-input"></span>
							</div>
							<button type="submit" class="btn btn-white btn-round btn-just-icon">
								<i class="material-icons">search</i><div class="ripple-container"></div>
							</button>
	                    </form>
					</div>
				</div>
			</nav>

			<?php echo $__env->yieldContent('content'); ?>

			<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>