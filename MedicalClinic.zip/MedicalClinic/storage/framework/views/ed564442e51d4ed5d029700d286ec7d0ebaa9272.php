			

			<?php $__env->startSection('content'); ?>
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
						<?php if(session('success')): ?> 
							<div class="alert alert-success">
								<button type="button" aria-hidden="true" class="close">×</button>
								<span><b> <?php echo e(session('success')); ?> </b></span>
							</div>
						<?php endif; ?>
						<?php if(session('error')): ?>
							<div class="alert alert-danger">
								<button type="button" aria-hidden="true" class="close">×</button>
								<span><b><?php echo e(session('error')); ?> </b></span>
							</div>
						<?php endif; ?>
	                    <a href="<?php echo e(url('/poliklinik')); ?>"><button class="btn btn-default"><i class="material-icons">keyboard_arrow_left</i> Back</button></a>
	                        <div class="card">
	                            <div class="card-header" data-background-color="red">
	                                <h4 class="title">Form Data Poliklinik</h4>
	                                <p class="category">Complete Data Poliklinik</p>
	                            </div>
	                            <div class="card-content">
	                                <form action="<?php echo e(empty($edit) ? url('poliklinik/add') :  url('poliklinik/edit/'. @$result->kd_poliklinik)); ?>" method="post">
										<?php echo e(csrf_field()); ?>

										<?php if(!empty($result)): ?>
											<?php echo e(method_field('PATCH')); ?>

										<?php endif; ?>
	                                    <div class="row">
	                                        <div class="col-md-12">
												<div class="form-group label-floating has-error">
													<label class="control-label">Nama Poliklinik</label>
													<input name="nama_poliklinik" type="text" class="form-control" value="<?php echo e(@$result->nama_poliklinik); ?>">
												</div>

												<div class="form-group label-floating has-error">
													<label class="control-label">Tarif</label>
													<input name="tarif" type="number" class="form-control" value="<?php echo e(@$result->tarif); ?>">
												</div>
	                                        </div>
	                                    </div>

	                                    <button type="submit" class="btn btn-danger pull-right">
											<?php if(empty($edit)): ?>
												Submit
											<?php else: ?>
												Edit
											<?php endif; ?>
										</button>
	                                    <div class="clearfix"></div>
	                                </form>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        <?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>