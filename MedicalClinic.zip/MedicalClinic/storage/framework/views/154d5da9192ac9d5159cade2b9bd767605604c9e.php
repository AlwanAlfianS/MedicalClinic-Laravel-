			

			<?php $__env->startSection('content'); ?>
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
	                        <a href="<?php echo e(url('resep/add')); ?>"><button class="btn btn-default"><i class="material-icons">add</i> Add Data Resep</button></a>
	                        <div class="card card-plain">
	                            <div class="card-header" data-background-color="red">
	                            		<h4 class="title">Data Resep</h4>
	                                <p class="category">Data resep MedicalClinic</p>
	                            </div>
	                            <div class="card-content table-responsive">
	                                <table class="table" id="dataTables-example">
	                                    <thead>
	                                    	<th><b>No</b></th>
	                                    	<th><b>Tanggal Resep</b></th>
	                                    	<th><b>Dokter</b></th>
	                                    	<th><b>Pasien</b></th>
	                                    	<th><b>Poliklinik</b></th>
											<th><b>Action</b></th>
	                                    </thead>
	                                    <tbody>
	                                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                                        <tr>
	                                        	<td><?php echo e($i++); ?></td>
												<td><?php echo e($row->tgl_resep); ?></td>
												<td><?php echo e($row->kd_dokter); ?></td>
												<td><?php echo e($row->kd_pasien); ?></td>
												<td><?php echo e($row->kd_poliklinik); ?></td>
												<td>
													<button class="btn btn-success btn-just-icon"><i class="material-icons">Edit</i></button>
													<button class="btn btn-danger btn-just-icon"><i class="material-icons">Clear</i></button>
												</td>
	                                        </tr>
	                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                                    </tbody>
	                                </table>

	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        <?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>