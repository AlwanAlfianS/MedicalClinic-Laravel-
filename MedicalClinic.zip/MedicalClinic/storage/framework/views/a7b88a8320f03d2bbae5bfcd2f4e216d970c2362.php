			

			<?php $__env->startSection('content'); ?>
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
						<?php if(session('success')): ?> 
							<div class="alert alert-success">
								<button type="button" aria-hidden="true" class="close">×</button>
								<span><b> <?php echo e(session('success')); ?> </b></span>
							</div>
						<?php endif; ?>
						<?php if(session('error')): ?>
							<div class="alert alert-danger">
								<button type="button" aria-hidden="true" class="close">×</button>
								<span><b><?php echo e(session('error')); ?> </b></span>
							</div>
						<?php endif; ?>
	                    <a href="<?php echo e(url('user')); ?>"><button class="btn btn-default"><i class="material-icons">keyboard_arrow_left</i> Back</button></a>
	                        <div class="card">
	                            <div class="card-header" data-background-color="red">
	                                <h4 class="title">Form Data User</h4>
	                                <p class="category">Complete Data User </p>
	                            </div>
	                            <div class="card-content">
	                                <form action="<?php echo e(empty($edit) ? url('user/add') : url('user/edit/'. @$result->id_user)); ?>" method="post" enctype="multipart/form-data">
										<?php echo e(csrf_field()); ?>

										<?php if(!empty($result)): ?>
											<?php echo e(method_field('PATCH')); ?>

										<?php endif; ?>
	                                    <div class="row">
	                                        <div class="col-md-12">
												<div class="form-group label-floating has-error">
													<label class="control-label">Username</label>
													<input name="username" type="text" class="form-control" value="<?php echo e(@$result->username); ?>">
												</div>
	                 
												<div class="form-group label-floating has-error">
													<label class="control-label">Password</label>
													<input name="password" type="password" class="form-control">
												</div>

												<div class="form-group is-empty is-fileinput has-error">
										            <input type="file" id="inputFile4" multiple="" name="foto" ">
										            <div class="input-group">
										              <input type="text" readonly="" class="form-control" placeholder="Choose image..." value="<?php echo e(@$result->foto); ?>">
										                <span class="input-group-btn input-group-sm">
										                  <button type="button" class="btn btn-fab btn-fab-mini">
										                    <i class="material-icons">add_a_photo</i>
										                  </button>
										                </span>
										            </div>
												 </div>
	                                        </div>
	                                    </div>

	                                    <button type="submit" class="btn btn-danger pull-right">Submit</button>
	                                    <div class="clearfix"></div>
	                                </form>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        <?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>