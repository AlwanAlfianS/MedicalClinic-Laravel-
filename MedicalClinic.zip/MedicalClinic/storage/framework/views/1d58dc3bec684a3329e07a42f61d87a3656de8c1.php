			

			<?php $__env->startSection('content'); ?>
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
						<?php if(session('success')): ?> 
							<div class="alert alert-success">
								<button type="button" aria-hidden="true" class="close">×</button>
								<span><b> <?php echo e(session('success')); ?> </b></span>
							</div>
						<?php endif; ?>
						<?php if(session('error')): ?>
							<div class="alert alert-danger">
								<button type="button" aria-hidden="true" class="close">×</button>
								<span><b><?php echo e(session('error')); ?> </b></span>
							</div>
						<?php endif; ?>
	                    <a href="<?php echo e(url('obat')); ?>"><button class="btn btn-default"><i class="material-icons">keyboard_arrow_left</i> Back</button></a>
	                        <div class="card">
	                            <div class="card-header" data-background-color="red">
	                                <h4 class="title">Form Data Obat</h4>
	                                <p class="category">Complete Data Obat</p>
	                            </div>
	                            <div class="card-content">
	                                <form action="<?php echo e(empty($edit) ? url('obat/add') : url('obat/edit/'. @$result->kd_obat)); ?>" method="post">
										<?php echo e(csrf_field()); ?>

										<?php if(!empty($result)): ?>
											<?php echo e(method_field('PATCH')); ?>

										<?php endif; ?>
	                                    <div class="row">
	                                        <div class="col-md-12">
												<div class="form-group label-floating has-error">
													<label class="control-label">Nama</label>
													<input name="nama_obat" type="text" class="form-control" value="<?php echo e(@$result->nama_obat); ?>">
												</div>
	                 
												<div class="form-group has-error">
													<label class="label txt-red">Jenis Obat</label>
													<select name="jenis_obat" class="form-control">
													  <option value="Serbuk" <?php echo e(@$result->jenis_obat == 'Serbuk' ? 'selected' : ''); ?>>Serbuk</option>
													  <option value="Sirup" <?php echo e(@$result->jenis_obat == 'Sirup' ? 'selected' : ''); ?>>Sirup</option>
													  <option value="Tablet" <?php echo e(@$result->jenis_obat == 'Tablet' ? 'selected' : ''); ?>>Tablet</option>
													  <option value="Kapsul" <?php echo e(@$result->jenis_obat == 'Kapsul' ? 'selected' : ''); ?>>Kapsul</option>
													</select>
												</div>

												<div class="form-group has-error">
													<label class="label txt-red">Kategori</label>
													<select name="kategori" class="form-control">
													  <option value="Obat Bebas" <?php echo e(@$result->kategori == 'Obat Bebas' ? 'selected' : ''); ?>>Obat Bebas</option>
													  <option value="Obat Bebas Terbatas" <?php echo e(@$result->kategori == 'Obat Bebas Terbatas' ? 'selected' : ''); ?>>Obat Bebas Terbatas</option>
													  <option value="Obat Keras" <?php echo e(@$result->kategori == 'Obat Keras' ? 'selected' : ''); ?>>Obat Keras</option>
													</select>
												</div>

												<div class="form-group label-floating has-error">
													<label class="control-label">Harga Obat</label>
													<input name="harga_obat" type="number" class="form-control" value="<?php echo e(@$result->harga_obat); ?>">
												</div>

												<div class="form-group label-floating has-error">
													<label class="control-label">Jumlah Obat</label>
													<input name="jml_obat" type="number" class="form-control" value="<?php echo e(@$result->jml_obat); ?>">
												</div>
	                                        </div>
	                                    </div>

	                                    <button type="submit" class="btn btn-danger pull-right">
											<?php if(empty($edit)): ?>
												Submit
											<?php else: ?>
												Edit
											<?php endif; ?>
										</button>
	                                    <div class="clearfix"></div>
	                                </form>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        <?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>