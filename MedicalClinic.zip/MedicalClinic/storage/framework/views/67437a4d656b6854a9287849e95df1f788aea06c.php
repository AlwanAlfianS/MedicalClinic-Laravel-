			

			<?php $__env->startSection('content'); ?>
			<div class="content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
							<?php if(session('success')): ?> 
								<div class="alert alert-success">
									<button type="button" aria-hidden="true" class="close">×</button>
									<span><b> <?php echo e(session('success')); ?> </b></span>
								</div>
							<?php endif; ?>
							<?php if(session('error')): ?>
								<div class="alert alert-danger">
									<button type="button" aria-hidden="true" class="close">×</button>
									<span><b><?php echo e(session('error')); ?> </b></span>
								</div>
							<?php endif; ?>
							<a href="<?php echo e(url('poliklinik/add')); ?>"><button class="btn btn-default"><i class="material-icons">add</i> Add Data Poliklinik</button></a>
	                        <div class="card card-plain">
	                            <div class="card-header" data-background-color="red">
	                            		<h4 class="title">Data Poliklinik</h4>
	                                <p class="category">Data Poliklinik MedicalClinic</p>
	                            </div>
	                            <div class="card-content table-responsive">
	                                <table class="table" id="dataTables-example">
	                                    <thead>
	                                    	<th><b>No</b></th>
	                                    	<th><b>Nama Poliklinik</b></th>
	                                    	<th><b>Tarif</b></th>
											<th><b>Action</b></th>
	                                    </thead>
	                                    <tbody>
	                                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	                                        <tr>
	                                        	<td><?php echo e($i++); ?></td>
	                                        	<td><?php echo e($row->nama_poliklinik); ?></td>
												<td>Rp.<?php echo e($row->tarif); ?></td>
												<td>
													<a href="<?php echo e(url('poliklinik/edit/'.$row->kd_poliklinik)); ?>"><button class="btn btn-success btn-just-icon"><i class="material-icons"></i> Edit</button></a>
													<a href="<?php echo e(url('/poliklinik/delete/'.$row->kd_poliklinik)); ?>"><button class="btn btn-danger btn-just-icon"><i class="material-icons"></i> Clear</button></a>
												</td>
	                                        </tr>
	                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	                                    </tbody>
	                                </table>

	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        <?php $__env->stopSection(); ?>
<?php echo $__env->make('templates/header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>