<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Obat extends Model
{
	protected $table = 't_obat';
	
    public $primaryKey = 'kd_obat';

    protected $fillable = [
    	'kd_obat', 'nama_obat', 'jenis_obat', 'kategori', 'harga_obat', 'jml_obat'
    ];
	
	public $timestamps = false;
	
	public $incrementing = false;
}
