<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Resep extends Model
{
    protected $table = 't_resep';

    protected $fillable = [
    	'tgl_resep', 'kd_obat', 'kd_pasien', 'kd_poliklinik'
    ];
}
