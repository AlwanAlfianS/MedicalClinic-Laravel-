<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Akun extends Model
{
    public $primaryKey = 'id_user';

    protected $table = 't_user';

    protected $fillable = [
    	'username', 'password', 'level', 'foto'
    ];
	
	protected $hidden = [
        'password', 'remember_token',
    ];
}
