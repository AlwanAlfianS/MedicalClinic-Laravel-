<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Poliklinik extends Model
{
	protected $table = 't_poliklinik';

	public $primaryKey = 'kd_poliklinik';
	
    protected $fillable = [
    	'kd_poliklinik', 'nama_poliklinik', 'tarif'
    ];
	
	public $timestamps = false;
	
	public $incrementing = false;

}
