<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dokter extends Model
{
    protected $primaryKey = 'kd_dokter';

    protected $table = 't_dokter';

    protected $fillable = [
    	'nama_dokter', 'spesialis', 'tlp_dokter', 'kd_poliklinik'
    ];
}
