<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pasien extends Model
{
    protected $primaryKey = 'kd_pasien';

    protected $table = 't_pasien';

    protected $fillable = [
    	'nama_pasien', 'alamat_pasien', 'jk_pasien', 'umur_pasien', 'tlp_pasien'
    ];
}
