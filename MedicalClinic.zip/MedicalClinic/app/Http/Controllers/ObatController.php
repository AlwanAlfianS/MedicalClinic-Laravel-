<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Obat;
use Illuminate\Support\Facades\DB;

class ObatController extends Controller
{
    public function index()
    {
        $data['i'] = 1;
        $data['result'] = Obat::all();
		$data['active'] = 'obat';
		
        return view('obat.index')->with($data);
    }

    public function create()
    {
		$data['active'] = 'obat';
        
        return view('obat.form')->with($data);
    }

    public function store(Request $request)
    {
        $key_obat = DB::table('t_obat')->select('kd_obat')->orderBy('kd_obat', 'desc')->limit('1')->get();
		
		if($key_obat->count()) {
			$kode = 'OBT';
			$number = substr($key_obat[0]->kd_obat, 3);
			$kd_obat = $this->next($kode, $number);
		} else {
			$kd_obat = 'OBT001';
		}
		
        $input = array(
			'kd_obat' => $kd_obat,
			'nama_obat' => $request->input('nama_obat'),
			'jenis_obat' => $request->input('jenis_obat'),
			'kategori' => $request->input('kategori'),
			'harga_obat' => $request->input('harga_obat'),
			'jml_obat' => $request->input('jml_obat')
		);
		
		$status = Obat::create($input);
		
		if ($status) {
			return redirect('obat')->with('success', 'Data berhasil ditambahkan');
		} else {
			return redirect('obat/add')->with('error', 'Data gagal ditambahkan');
		}
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $data['edit'] = TRUE;
		$data['active'] = 'obat';
		$data['result'] = Obat::where('kd_obat', $id)->first();
		return view('obat.form')->with($data);
    }

    public function update(Request $request, $id)
    {
        $input = $request->all(); 
		
		$status = Obat::where('kd_obat', $id)->first()->update($input);
		
		if ($status) {
			return redirect('obat')->with('success', 'Data berhasil diubah');
		} else {
			return redirect('obat/edit/'.$id)->with('error', 'Data gagal diubah');
		}
    }

    public function destroy($id)
    {
        $obat = Obat::find($id);
		$obat->delete();
		
		return redirect('obat')->with('success', 'Data berhasil dihapus');
    }
	
	public function next($kode, $number) 
	{
		$number = (int) $number;
		$number = $number + 1;
		$ln = strlen($number);
		
		for ($i=2; $i >= $ln; $i--) {
			$kode .= '0';
		}
		
		return $kode . $number;
	}
}
