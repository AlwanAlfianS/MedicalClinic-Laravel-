<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Poliklinik;
use Illuminate\Support\Facades\DB;

class PoliklinikController extends Controller
{
    public function index()
    {
        $data['i'] = 1;
        $data['result'] = Poliklinik::all();
		$data['active'] = 'poliklinik';

        return view('poliklinik.index')->with($data);
    }

    public function create()
    {
		$data['active'] = 'poliklinik';
        return view('poliklinik.form')->with($data);
    }

    public function store(Request $request)
    {
		$key_poliklinik = DB::table('t_poliklinik')->select('kd_poliklinik')->orderBy('kd_poliklinik', 'desc')->limit('1')->get();
		
		if($key_poliklinik->count()) {
			$kode = 'PLK';
			$number = substr($key_poliklinik[0]->kd_poliklinik, 3);
			$kd_poliklinik = $this->next($kode, $number);
		} else {
			$kd_poliklinik = 'PLK001';
		}
		
        $input = array(
			'kd_poliklinik' => $kd_poliklinik,
			'nama_poliklinik' => $request->input('nama_poliklinik'),
			'tarif' => $request->input('tarif')
		);
		
		$status = Poliklinik::create($input);
		
		if ($status) {
			return redirect('poliklinik')->with('success', 'Data berhasil ditambahkan');
		} else {
			return redirect('poliklinik/add')->with('error', 'Data gagal ditambahkan');
		}
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $data['edit'] = TRUE;
		$data['active'] = 'poliklinik';
		$data['result'] = Poliklinik::where('kd_poliklinik', $id)->first();
		return view('poliklinik.form')->with($data);
    }

    public function update(Request $request, $id)
    {
        $input = $request->all(); 
		
		$status = Poliklinik::where('kd_poliklinik', $id)->first()->update($input);
		
		if ($status) {
			return redirect('poliklinik')->with('success', 'Data berhasil diubah');
		} else {
			return redirect('poliklinik/edit/'.$id)->with('error', 'Data gagal diubah');
		}
    }

    public function destroy($id)
    {
        $poliklinik = Poliklinik::find($id);
		$poliklinik->delete();
		
		return redirect('poliklinik')->with('success', 'Data berhasil dihapus');
    }
	
	public function next($kode, $number) 
	{
		$number = (int) $number;
		$number = $number + 1;
		$ln = strlen($number);
		
		for ($i=2; $i >= $ln; $i--) {
			$kode .= '0';
		}
		
		return $kode . $number;
	}
}
