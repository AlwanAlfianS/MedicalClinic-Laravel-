<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Akun;
use Illuminate\Support\Facades\DB;
use Hash;
use Auth;

class AkunController extends Controller
{
    public function index()
    {
    	$data['i'] = 1;
    	$data['result'] = DB::table('t_user')->where('level', '0')->get();
		$data['active'] = 'user';
        return view('user.index')->with($data);
    }

    public function create()
    {
		$data['active'] = 'user';
		
        return view('user.form')->with($data);
    }

    public function store(Request $request)
    {
		$rules = array(
			'username'	=> 'required|unique:t_user',
			'foto' 			=> 'required|mimes:jpeg,png|max:2048'
		);
		
		$this->validate($request, $rules);
		
        $input = array(
			'username' => $request->input('username'),
			'password' => Hash::make($request->input('password')),
			'level' => '0',
			'foto' => $request->input('foto'),
		);
		
		if ($request->hasFile('foto') && $request->file('foto')->isValid()) {
			$filename = $input['username'] . "." . $request->file('foto')->getClientOriginalExtension();
			$request->file('foto')->storeAs('', $filename);
			$input['foto'] = $filename;
		}
		
		$status = Akun::create($input);
		
		if ($status) {
			return redirect('user')->with('success', 'Data berhasil ditambahkan');
		} else {
			return redirect('user/add')->with('error', 'Data gagal ditambahkan');
		}
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $data['edit'] = TRUE;
		$data['active'] = 'user';
		$data['result'] = Akun::where('id_user', $id)->first();
		return view('user.form')->with($data);
    }

    public function update(Request $request, $id)
    {
        $rules = array(
			'foto' 			=> 'required|mimes:jpeg,png|max:2048'
		);
		
		$this->validate($request, $rules);
		
        $input = array(
			'username' => $request->input('username'),
			'password' => Hash::make($request->input('password')),
			'level' => '0',
			'foto' => $request->input('foto'),
		);
		
		if ($request->hasFile('foto') && $request->file('foto')->isValid()) {
			$filename = $input['username'].".". $request->file('foto')->getClientOriginalExtension();
			$request->file('foto')->storeAs('', $filename);
			$input['foto'] = $filename;
		}
		
		$status = Akun::where('id_user', $id)->first()->update($input);
		
		if ($status) {
			return redirect('user')->with('success', 'Data berhasil diubah');
		} else {
			return redirect('user/edit/'.$id)->with('error', 'Data gagal diubah');
		}
    }

    public function destroy($id)
    {
        $akun = Akun::find($id);
		$akun->delete();
		
		return redirect('user')->with('success', 'Data berhasil dihapus');
    }
	
	public function logout()
	{
		Auth::logout();
		return redirect('/');
	}
}
