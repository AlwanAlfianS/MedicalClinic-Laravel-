<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Pasien;

class PasienController extends Controller
{
    public function index()
    {
        $data['i'] = 1;
        $data['result'] = Pasien::all();
		$data['active'] = 'pasien';
        return view('pasien.index')->with($data);
    }

    public function create()
    {
        return view('pasien.form');
    }

    public function store(Request $request)
    {
        //
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
