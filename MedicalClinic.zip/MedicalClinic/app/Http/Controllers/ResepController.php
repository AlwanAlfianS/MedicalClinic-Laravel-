<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Resep;

class ResepController extends Controller
{
    public function index()
    {
        $data['i'] = 1;
        $data['result'] = Resep::all();
		$data['active'] = 'resep';
        return view('resep.index')->with($data);
    }

    public function create()
    {
        return view('resep.form');
    }

    public function store(Request $request)
    {
        //
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
