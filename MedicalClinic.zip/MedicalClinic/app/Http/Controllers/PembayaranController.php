<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Pembayaran;

class PembayaranController extends Controller
{
    public function index()
    {
        $data['i'] = 1;
        $data['result'] = Pembayaran::all();
		$data['active'] = 'pembayaran';
        return view('pembayaran.index')->with($data);
    }

    public function create()
    {
        return view('pembayaran.form');
    }

    public function store(Request $request)
    {
        //
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
