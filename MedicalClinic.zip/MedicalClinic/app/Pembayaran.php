<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pembayaran extends Model
{
    protected $primaryKey = 'nmr_bayar';

    protected $table = 't_pembayaran';

    protected $fillable = [
		'kd_pasien', 'tgl_bayar', 'total_pembayaran'
    ];
}
