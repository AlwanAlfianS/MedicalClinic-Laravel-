<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableTResep extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('t_resep', function(Blueprint $table) {
			$table->string('kd_resep', 10)->primary();
			$table->date('tgl_resep');
			$table->string('kd_dokter', 10);
			$table->string('kd_pasien', 10);
			$table->string('kd_poliklinik', 10);
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_resep');
    }
}
