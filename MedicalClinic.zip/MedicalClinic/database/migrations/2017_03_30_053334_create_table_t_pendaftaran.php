<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableTPendaftaran extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('t_pendaftaran', function(Blueprint $table) {
			$table->string('nmr_pendaftaran', 10)->primary();
			$table->date('tgl_pendaftaran');
			$table->string('kd_dokter', 10);
			$table->string('kd_pasien', 10);
			$table->string('kd_poliklinik', 10);
			$table->float('biaya', 10);
			$table->string('ket', 100);
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_pendaftaran');
    }
}
