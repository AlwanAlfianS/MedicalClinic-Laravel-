<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableTDokter extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
       Schema::create('t_dokter', function(Blueprint $table) {
			$table->string('kd_dokter', 10)->primary();
			$table->string('nama_dokter', 100);
			$table->string('spesialis', 50);
			$table->string('tlp_dokter', 12);
			$table->string('kd_poliklinik', 10);
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_dokter');
    }
}
