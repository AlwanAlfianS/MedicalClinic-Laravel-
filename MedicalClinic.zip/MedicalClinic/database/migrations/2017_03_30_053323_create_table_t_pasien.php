<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableTPasien extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('t_pasien', function(Blueprint $table) {
			$table->string('kd_pasien', 10)->primary();
			$table->string('nama_pasien', 100);
			$table->text('alamat_pasien');
			$table->enum('jk_pasien', array('Laki-laki', 'Perempuan'));
			$table->string('umur_pasien', 10);
			$table->string('tlp_pasien', 10);
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_pasien');
    }
}
