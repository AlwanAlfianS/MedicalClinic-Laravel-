<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableTObat extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('t_obat', function(Blueprint $table) {
			$table->string('kd_obat', 10)->primary();
			$table->string('nama_obat', 50);
			$table->enum('jenis_obat', array('Serbuk', 'Sirup', 'Tablet', 'Kapsul'));
			$table->enum('kategori', array('Obat Bebas', 'Obat Bebas Terbatas', 'Obat Keras'));
			$table->float('harga_obat', 10);
			$table->float('jml_obat', 10);
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_obat');
    }
}
