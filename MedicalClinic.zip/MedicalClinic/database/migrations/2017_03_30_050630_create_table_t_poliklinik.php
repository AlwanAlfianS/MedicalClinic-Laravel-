<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTableTPoliklinik extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('t_poliklinik', function(Blueprint $table) {
			$table->string('kd_poliklinik', 10)->primary();
			$table->string('nama_poliklinik', 100);
			$table->float('tarif', 10);
		});
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('t_poliklinik');
    }
}
