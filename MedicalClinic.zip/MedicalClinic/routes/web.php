<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
	return view('welcome');
});
	
Route::auth();

Route::group(['middleware'=>'auth'], function() {
	Route::get('/logout', 'AkunController@logout');
	
	Route::get('/user', 'AkunController@index');
	Route::get('/pasien', 'PasienController@index');
	Route::get('/dokter', 'DokterController@index');
	Route::get('/poliklinik', 'PoliklinikController@index');
	Route::get('/obat', 'ObatController@index');
	Route::get('/resep', 'ResepController@index');
	Route::get('/pembayaran', 'PembayaranController@index');

	Route::get('/user/add', 'AkunController@create');
	Route::post('/user/add', 'AkunController@store');
	Route::get('/user/edit/{id}', 'AkunController@edit');
	Route::patch('/user/edit/{id}', 'AkunController@update');
	Route::get('/user/delete/{id}', 'AkunController@destroy');

	Route::get('/pasien/add', 'PasienController@create');
	Route::post('/pasien/add', 'PasienController@store');
	Route::get('/pasien/edit/{id}', 'PasienController@edit');
	Route::patch('/pasien/edit/{id}', 'PasienController@update');
	Route::delete('/pasien/delete/{id}', 'PasienController@destroy');

	Route::get('/dokter/add', 'DokterController@create');
	Route::post('/dokter/add', 'DokterController@store');
	Route::get('/dokter/edit/{id}', 'DokterController@edit');
	Route::patch('/dokter/edit/{id}', 'DokterController@update');
	Route::delete('/dokter/delete/{id}', 'DokterController@destroy');

	Route::get('/poliklinik/add', 'PoliklinikController@create');
	Route::post('/poliklinik/add', 'PoliklinikController@store');
	Route::get('/poliklinik/edit/{id}', 'PoliklinikController@edit');
	Route::patch('/poliklinik/edit/{id}', 'PoliklinikController@update');
	Route::delete('/poliklinik/delete/{id}', 'PoliklinikController@destroy');

	Route::get('/obat/add', 'ObatController@create');
	Route::post('/obat/add', 'ObatController@store');
	Route::get('/obat/edit/{id}', 'ObatController@edit');
	Route::patch('/obat/edit/{id}', 'ObatController@update');
	Route::delete('/obat/delete/{id}', 'ObatController@destroy');

	Route::get('/resep/add', 'ResepController@create');
	Route::post('/resep/add', 'ResepController@store');
	Route::get('/resep/edit/{id}', 'ResepController@edit');
	Route::patch('/resep/edit/{id}', 'ResepController@update');
	Route::delete('/resep/delete/{id}', 'ResepController@destroy');

	Route::get('/pembayaran/add', 'PembayaranController@create');
	Route::post('/pembayaran/add', 'PembayaranController@store');
	Route::delete('/pembayaran/delete/{id}', 'PembayaranController@destroy');
});